package prog02;

import java.io.*;

/**
 * This is an implementation of PhoneDirectory that uses a sorted
 * array to store the entries.
 * @author vjm
 */
public class SortedPD extends ArrayBasedPD {

	
	protected DirectoryEntry add (int index, String name, String number) {
		if (size == theDirectory.length)
			reallocate();
		System.out.println(number);
		//return new DirectoryEntry("fred", "555");
		//System.out.println(theDirectory[index].getNumber());
		//theDirectory[size] = new DirectoryEntry(theDirectory[index].getName(), theDirectory[index].getNumber());
		
		//theDirectory[index] = new DirectoryEntry(name, number);
		
		//size++;
		//return theDirectory[index];
		for (int i = size -1; i >= index; i--) {
			theDirectory[i+1] = theDirectory[i];
		}
		theDirectory[index]	 = new DirectoryEntry(name, number);
		size++;
		return theDirectory[index];
	}
	
	
	protected int find (String name) {
		for (int idx = 0; idx < size; idx++) {
			
			DirectoryEntry entry = theDirectory[idx];
			
			if (entry.getName().equals(name))
				return idx;
		}
		

		return -1;
	}
	
	
	public String removeEntry (String name) {
		int index = find(name);
		if (index >= 0) {
			
			return remove(index).getNumber();
		}
			
		
		else
			return null;
		
	}
}
