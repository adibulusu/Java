package prog03;

import prog02.GUI;
import prog02.UserInterface;

/**
 *
 * @author vjm
 */
public class Main {
	/** Use this variable to store the result of each call to fib. */
	public static double fibn;

	/**
	 * Determine the average time in microseconds it takes to calculate the n'th
	 * Fibonacci number.
	 * 
	 * @param fib    an object that implements the Fib interface
	 * @param n      the index of the Fibonacci number to calculate
	 * @param ncalls the number of calls to average over
	 * @return the average time per call
	 */
	public static double averageTime(Fib fib, int n, int ncalls) {
		// Get the current time in nanoseconds.
		long start = System.nanoTime();

		// Call fib(n) ncalls times (needs a loop!).
		for (int i = 0; i <= ncalls; i++) {
			fib.fib(n);
			// System.out.println(i);
		}

		fibn = fib.fib(n);

		// Get the current time in nanoseconds.
		long end = System.nanoTime();

		// Return the average time converted to microseconds averaged over ncalls.
		return (end - start) / 1000.0 / ncalls;
	}

	/**
	 * Determine the time in microseconds it takes to to calculate the n'th
	 * Fibonacci number. Average over enough calls for a total time of at least one
	 * second.
	 * 
	 * @param fib an object that implements the Fib interface
	 * @param n   the index of the Fibonacci number to calculate
	 * @return the time it it takes to compute the n'th Fibonacci number
	 */
	public static double accurateTime(Fib fib, int n) {
		// Get the time in microseconds using the time method above.
		double t = averageTime(fib, n, 1);
		// System.out.println(t);
		// If the time is (equivalent to) more than a second, return it.
		if (t > 1000000)
			return t;

		// Estimate the number of calls that would add up to one second.
		// Use (int)(YOUR EXPESSION) so you can save it into an int variable.
		int numcalls = (int) (100000 / t);

		// Get the average time using averageTime above and that many
		// calls and return it.
		return averageTime(fib, n, numcalls);
	}

	private static UserInterface ui = new GUI("Fibonacci experiments");
	// private static UserInterface ui = new TestUI("Fibonacci experiments");

	public static void doExperiments(Fib fib) {
		System.out.println("doExperiments " + fib);
		// EXERCISES 8 and 9

		while (true) {

			String[] input = new String[2];
			int[] number = new int[2];
			boolean isNumber = false;
			double[] time = new double[2];
			double[] result = new double[2];

			while (!isNumber) {

				try {
					input[0] = ui.getInfo("Enter an integer: ");
					if (input[0] == null)
						return;
					number[0] = Integer.parseInt(input[0]);
					isNumber = true;

				}

				catch (NumberFormatException e) {
					ui.sendMessage("Not an integer, try again.");
				}
			}

			if (fib instanceof ExponentialFib && number[0] > 40) {

				ui.sendMessage("Takes too long to compute");
				return;

			}

			// get time to compute nth fib number
			time[0] = accurateTime(fib, number[0]);

			// compute nth fib number
			result[0] = fib.fib(number[0]);

			ui.sendMessage(
					String.format("fib(%d) = %.2f computed in %.5f microseconds", number[0], result[0], time[0]));
			isNumber = false;

			while (!isNumber) {

				try {
					input[1] = ui.getInfo("Enter an integer: ");
					if (input[1] == null)
						return;
					number[1] = Integer.parseInt(input[1]);
					isNumber = true;

				}

				catch (NumberFormatException e) {
					ui.sendMessage("Not an integer, try again.");
				}

			}

			if (fib instanceof ExponentialFib && number[1] > 40) {
				ui.sendMessage("Takes too long to compute");
				return;

			}

			// get second integer

			time[1] = averageTime(fib, number[0], number[1]);

			ui.sendMessage(String.format("The average time on input %d is %.5f microseconds", number[1], time[1]));
			ui.sendMessage(String.format("The error on the average time is %.5f",
					Math.abs(time[1] - time[0]) / time[0] * 100));

		}

	}

	static void doExperiments() {

		String[] commands = { "ExponentialFib", "LinearFib", "LogFib", "ConstantFib", "MysteryFib", "EXIT" };
		boolean running = true;
		while (running) {
			int choice = ui.getCommand(commands);
			switch (choice) {
			case 0:
				doExperiments(new ExponentialFib());
				break;
			case 1:
				doExperiments(new LinearFib());
				break;
			case 2:
				doExperiments(new LogFib());
				break;
			case 3:
				doExperiments(new ConstantFib());
				break;
			case 4:
				doExperiments(new MysteryFib());
				break;
			case 5:
				running = false;
				break;
			}
		}

	}

	static void labExperiments() {
		// Create (Exponential time) Fib object and test it.
		Fib efib = new ConstantFib();
		System.out.println(efib);
		for (int i = 0; i < 11; i++)
			System.out.println(i + " " + efib.fib(i));

		// Determine running time for n1 = 20 and print it out.
		int n1 = 20;
		double time1 = accurateTime(efib, n1);
		System.out.println("n1 " + n1 + " time1 " + time1);

		// Calculate constant: time = constant times O(n).
		double c = time1 / efib.O(n1);
		System.out.println("c " + c);

		// Estimate running time for n2=30.
		int n2 = 30;
		double time2est = c * efib.O(n2);
		System.out.println("n2 " + n2 + " estimated time " + time2est);

		// Calculate actual running time for n2=30.
		double time2 = accurateTime(efib, n2);
		System.out.println("n2 " + n2 + " actual time " + time2);

		// estimate fib(100)
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		labExperiments();

		// doExperiments(new LinearFib());
		doExperiments();
	}
}
