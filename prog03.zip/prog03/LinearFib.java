package prog03;

/**
 *
 * @author vjm
 */
public class LinearFib implements Fib
{

	@Override
	public double fib(int n) 
	{
		int a = 0;
		int b = 1;
		int c = 0;
		
		if ( n > 1 )
		{
			for (int i = 2; i <= n; i++)
			{
				
				c = a + b;
				a = b;
				b = c;
				
						
			}
			return c;
		}
		else
		{
			return n;
		}
		
		
	}

	@Override
	public double O(int n) 
	{
		// TODO Auto-generated method stub
		if (n == 0 || n == 1)
			return 1;
		else
			return 2 * (n-1) + 1;
		
	}
	
	
	
	
		
		
	
	
}

