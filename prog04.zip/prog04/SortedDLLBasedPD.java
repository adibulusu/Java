package prog04;



/** This is an implementation of the prog02.PhoneDirectory interface
 *   that uses a doubly linked list to store the data.
 *   @author vjm
 */
public class SortedDLLBasedPD extends DLLBasedPD {
    
  /** Add a new entry at a location.
      @param location The location to add the new entry, null to add
      it at the end of the list
      @param name The name in the new entry
      @param number The number in the new entry
      @return the new entry
  */
  protected DLLEntry add (String name, String number) {
    DLLEntry newEntry = new DLLEntry(name, number);
    if (name.equals("")) {
      	try {
			throw new Exception("Name cannot be empty");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Name cannot be empty");
			e.printStackTrace();
		}
    } //else if (number.equals("")) {
      	//try {
			//throw new Exception("Number cannot be empty");
		//} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		//}
    
    
   
    if (head != null)
    {
    	 for (DLLEntry entry = head; entry != null; entry = entry.getNext())
         {
			if (newEntry.getName().compareToIgnoreCase(entry.getName()) < 0)
            {
                DLLEntry prevEntry = entry.getPrevious();
              	if (prevEntry != null) 
                {
              		prevEntry.setNext(newEntry);
                }
                else
                {
					head = newEntry;
                }
                entry.setPrevious(newEntry);
                newEntry.setPrevious(prevEntry);
                newEntry.setNext(entry);
              	return newEntry;
            }
        }
        // Add to the tail section
        newEntry.setPrevious(tail);
        tail.setNext(newEntry);
        tail = newEntry;
    	
    }
    else
    {
    	head = newEntry;
    	tail = newEntry;
    }

    return newEntry;
  }

  /** Find an entry in the directory.
      @param name The name to be found
      @return The entry with the same name or null if it is not there.
  */
  protected DLLEntry find (String name) {
    // EXERCISE
    // For each entry in the directory.
    // What is the first?  What is the next?  How do you know you got them all?
	  DLLEntry entry;
	  for (entry = head; entry != null; entry = entry.getNext())
	  {
		  if (this.found(entry, name))
			  return entry;
	  }
      // If this is the entry you want

        // return it.

    return null; // Name not found.
  }
  
  /** Check if a name is found at a location.
      @param location The location to check
      @param name The name to look for at that location
      @return false, if location is null or it does not have that
      name; true, otherwise.
  */
  protected boolean found (DLLEntry location, String name) {
    if (location == null)
      return false;
    return location.getName().equals(name);
  } 
  
}